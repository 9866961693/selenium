import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;

public class Cooking {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.firefox.bin",
				"C:/Users/natyam/AppData/Local/Mozilla Firefox/firefox.exe");
        FirefoxProfile profile = new FirefoxProfile();
        profile.setPreference("network.proxy.type", 1);
        profile.setPreference("network.proxy.http", "10.219.96.26");
        profile.setPreference("network.proxy.http_port", 8080);
        profile.setPreference("network.proxy.ssl", "10.219.96.26");
        profile.setPreference("network.proxy.ssl_port", 8080);
        
        
        FirefoxDriver driver = new FirefoxDriver(profile);
        driver.get("file:///C:/Users/natyam/Desktop/case%20study/Recipe_class_registration.htm");	
        Thread.sleep(1000);
		System.out.println(driver.getTitle());
		String title="Online Cooking Class Enquiry Form";
		//To verify the title of the page
		if(title.equals(driver.getTitle()))
	        {
	        	System.out.println("Title is verified");
	        }
	        else
	        {
	        	System.out.println("title is not verified");
	        }
		Thread.sleep(1000);
		//Verify there is a text on the web page �Online Cooking School"
		boolean b = driver.getPageSource().contains("Online cooking school");
		System.out.println("Expected text is present");
		Thread.sleep(10000);
		
		//Sending text to firstname by using xpath
		driver.findElement(By.xpath("//*[@id='fname']")).sendKeys("Ishwarya");
		System.out.println("The execution is paused for 10 seconds and first name is successfully entered..!!!");
		Thread.sleep(10000);
		
		//Sending text to lastname by using name
        driver.findElement(By.name("lname")).sendKeys("Atyam");
        System.out.println("The execution is paused for 10 seconds and last name is successfully entered..!!!");
        Thread.sleep(10000);
        
        //Sending text to email by using id
        driver.findElement(By.id("emails")).sendKeys("ishwarya.atyam@gmail.com");
        System.out.println("The execution is paused for 10 seconds and email is successfully entered..!!!");
        Thread.sleep(10000);
        
        //Sending text to mobile by using cssSelector
        driver.findElement(By.cssSelector("*[name='mobile']")).sendKeys("9866961693");
        System.out.println("The execution is paused for 10 seconds and mobile no is successfully entered..!!!");
        Thread.sleep(10000);
        
        //selecting receipe by using Index
        Select non= new Select(driver.findElement(By.name("D6")));
		non.selectByIndex(2);
		System.out.println("The execution is paused for 10 seconds and category of receipe interested is successfully selected..!!!");
		Thread.sleep(10000);
		 
		//Verify that the user has selected Non-Veg  from the Category of recipes interested dropdown box.
		WebElement Verifynon = non.getFirstSelectedOption();
		String noncheck = Verifynon.getText();
		System.out.println("receipes  "+noncheck);
		System.out.println("receipe is verified");
		 
		//selecting city by using visible text
		Select city=new Select(driver.findElement(By.name("D5")));
	    city.selectByVisibleText("Mumbai");
	    System.out.println("The execution is paused for 10 seconds and city preference is  successfully entered..!!!");
	    Thread.sleep(10000);
	    
	    //Verify that the user has selected Mumbai as city from the city preference dropdown box.
	     WebElement Verifycity = city.getFirstSelectedOption();
		 String citycheck = Verifycity.getText();
		 System.out.println("city  "+citycheck);
		 System.out.println("city is verified");
		 
	    //selecting mode by using value
	    Select mode=new Select(driver.findElement(By.name("D4")));
	    mode.selectByValue("mercedes");
	    System.out.println("The execution is paused for 10 seconds and mode of learning is  successfully entered..!!!");
	    Thread.sleep(10000);
	    
	    //Verify that the user has selected �In house training� from the mode of learning dropdown box
	     WebElement Verifymode = mode.getFirstSelectedOption();
		 String modecheck = Verifymode.getText();
		 System.out.println("mode  "+modecheck);
		 System.out.println("mode is verified");
		 
	    //selecting duration by using visible text
	    Select duration=new Select(driver.findElement(By.xpath("html/body/form/table/tbody/tr[9]/td[2]/select")));
	    duration.selectByVisibleText("6 months");
	    System.out.println("The execution is paused for 10 seconds and mode of learning is  successfully entered..!!!");
	    Thread.sleep(10000);
	   
	    //Verify that the user has selected �6 months� from the interested course duration dropdown box.
	     WebElement Verifyduration = duration.getFirstSelectedOption();
		 String durationcheck = Verifyduration.getText();
		 System.out.println("duration  "+durationcheck);
		 System.out.println("duration is verified");

		 //sending data to the enquiry by using name
	    driver.findElement(By.name("enqdetails")).sendKeys("What are the timings");
	    Thread.sleep(10000);
	    
	    //clicking on the Enquire now button
	    driver.findElement(By.className("auto-style1")).click();
	    Thread.sleep(10000);
	    
	    if( driver.switchTo().alert().getText()  != null)
	    {
	    	System.out.println(driver.switchTo().alert().getText());
	    }
	    
	    //clicking on the alert box
	    driver.switchTo().alert().accept();
	    
	    //Verify the text �Our location representative will contact you soon� after submission of form.
		boolean b1 = driver.getPageSource().contains("Our location representative will contact you soon");
		System.out.println("Expected text is present");
		
		//navigating to the online cooking class enquiry page
		driver.navigate().to("file:///C:/Users/natyam/Desktop/case%20study/Recipe_class_registration.htm");
		
		//Click on the hyperlink Download our Recipe class Brochure
		driver.findElement(By.partialLinkText("Download our Recipe class Brochure")).click();
		
		System.out.println("Execution is paused for 15 seconds....Please wait");
		Thread.sleep(15000);
		driver.close();
		System.out.println("Window closed.");

	}

}
