import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JunitDemo {
	WebDriver driver= new ChromeDriver();
	@BeforeClass
	public static void beforeclasstest()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/natyam/Desktop/chromedriver.exe");
       
	  }
	
	@Before
	public void beforetest()
	{
		System.out.println("Verification Starting.......");
	}
	
	
	@Test
	public void test() throws InterruptedException 
	{
		driver.get("file:///C:/Users/natyam/Desktop/case%20study/Recipe_class_registration.htm");	
		String expectedtitle="Online Cooking Class Enquiry Form";
		String actualtitle = driver.getTitle();
		System.out.println(actualtitle);
	    assertEquals(expectedtitle, actualtitle);
	}
	
	@Test
	public void test1() throws InterruptedException 
	{
		
				driver.get("file:///D:/150682/M4/case%20study/Recipe_class_registration.htm");
				  if(driver.getPageSource().contains("Online Cooking School"))
			      {
			    	  System.out.println("Online Cooking School Text present in the page source");
				  }
				  else
				  {
					  System.out.println("Error");
				  }
	} 
	@After
	public void aftertest()
	{
		System.out.println("Verification ended");
		//driver.quit();
	}
	
	
}
